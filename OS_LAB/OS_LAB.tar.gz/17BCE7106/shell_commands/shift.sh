echo $# $*
shift
echo $# $*
shift
echo $# $*
