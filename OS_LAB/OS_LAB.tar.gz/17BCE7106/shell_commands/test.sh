#!/bin/sh
echo you have executed $0
echo you hvae $# parameters
echo first is $1
echo second is $2
echo `expr $1 + $2`

